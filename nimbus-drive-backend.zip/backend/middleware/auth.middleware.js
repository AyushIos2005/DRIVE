const jwt = require('jsonwebtoken');
const userModel = require('../models/user.model');

async function authMiddleware(req, res, next) {
    const token = req.cookies.token;

    if (!token) {
        if (req.originalUrl.startsWith('/api/')) {
            return res.status(401).json({ message: 'Unauthorized, please login' });
        }
        return res.redirect('/api/user/login');
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_KEY);
        const user = await userModel.findById(decoded.userId).select('-password');

        if (!user) {
            throw new Error('User not found');
        }

        req.user = user;
        next();
    } catch (err) {
        res.clearCookie('token');
        if (req.originalUrl.startsWith('/api/')) {
            return res.status(401).json({ message: 'Session expired, please login again' });
        }
        return res.redirect('/api/user/login');
    }
}

module.exports = authMiddleware;
