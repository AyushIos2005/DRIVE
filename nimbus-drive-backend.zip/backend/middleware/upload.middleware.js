const multer = require('multer');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const uploadRoot = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(uploadRoot)) {
    fs.mkdirSync(uploadRoot, { recursive: true });
}

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const userDir = path.join(uploadRoot, String(req.user._id));
        if (!fs.existsSync(userDir)) {
            fs.mkdirSync(userDir, { recursive: true });
        }
        cb(null, userDir);
    },
    filename: function (req, file, cb) {
        const unique = crypto.randomBytes(16).toString('hex') + path.extname(file.originalname);
        cb(null, unique);
    }
});

const upload = multer({
    storage,
    limits: { fileSize: 200 * 1024 * 1024 } // 200 MB per file
});

module.exports = upload;
module.exports.uploadRoot = uploadRoot;
