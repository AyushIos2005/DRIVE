const express = require('express')
const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')

const userRoute = express.Router();

const { body,validationResult } = require("express-validator")
const userModel = require("../models/user.model");
const authMiddleware = require("../middleware/auth.middleware");




userRoute.get('/register',(req,res) => {
    res.render("register")
})

userRoute.post('/register',
    body('email').trim().isEmail(),
    body('password').trim().isLength({min : 5}),
   async (req,res) => {
        const errors = validationResult(req); 
        if(!errors.isEmpty()){
            return res.status(400).json(
                {
                    errors : errors.array(),
                    message : 'Invalid data'
                }
            )
        }
        
        const { email,username,password } = req.body;

        try {
            const hashPassword = await bcrypt.hash(password,10);
            const newUser = await userModel.create({
                email,
                username,
                password : hashPassword
            })

            const userSafe = newUser.toObject();
            delete userSafe.password;

            const token = jwt.sign({
                userId : newUser._id,
                email : newUser.email,
            },
            process.env.JWT_KEY,
            { expiresIn : '7d' }
            )

            res.cookie('token', token, {
                httpOnly : true,
                maxAge : 7 * 24 * 60 * 60 * 1000
            })

            res.status(201).json(userSafe);
        } catch (err) {
            if(err.code === 11000){
                return res.status(409).json({
                    message : 'Email or username is already registered'
                })
            }
            console.error(err);
            return res.status(500).json({
                message : 'Something went wrong, please try again'
            })
        }

})

userRoute.get("/login",(req,res) => {
    res.render("login")
})

userRoute.post("/login", 
    body('email').trim().isEmail(),
    body('password').trim().isLength({ min:5 }),
    async(req,res) => {
        const errors = validationResult(req);

        if(!errors.isEmpty()){
            return res.status(400).json({
                error: errors.array(),
                message : 'Invalid data'
            })
        }

        const { email , password } = req.body;

        try {
            const user = await userModel.findOne({
                email : email
            })

            if(!user){
                return res.status(400).json({
                    message : 'Email or password is incorrect'
                })
            }

            const isMatch = await bcrypt.compare(password,user.password);

            if(!isMatch){
                return res.status(400).json({
                    message : 'Email or password is incorrect'
                })
            }

            const token = jwt.sign({
                userId : user._id,
                email : user.email,
            },
            process.env.JWT_KEY,
            { expiresIn : '7d' }
        )

        res.cookie('token',token, {
            httpOnly : true,
            maxAge : 7 * 24 * 60 * 60 * 1000
        })

        res.json({
            token
        })
        } catch (err) {
            console.error(err);
            return res.status(500).json({
                message : 'Something went wrong, please try again'
            })
        }

    }


)

userRoute.get('/me', authMiddleware, (req, res) => {
    res.json({ user: req.user });
})

userRoute.get('/logout', (req, res) => {
    res.clearCookie('token');
    res.redirect('/api/user/login');
})

module.exports = userRoute;