const express = require('express');
const path = require('path');
const fs = require('fs');

const fileRoute = express.Router();

const authMiddleware = require('../middleware/auth.middleware');
const upload = require('../middleware/upload.middleware');
const fileModel = require('../models/file.model');
const folderModel = require('../models/folder.model');

fileRoute.use(authMiddleware);

// Upload one or more files into a folder (folder = null means root)
fileRoute.post('/upload', upload.array('files', 20), async (req, res) => {
    try {
        const folderId = req.body.folder && req.body.folder !== 'null' ? req.body.folder : null;

        if (!req.files || req.files.length === 0) {
            return res.status(400).json({ message: 'No files were uploaded' });
        }

        const created = await Promise.all(req.files.map((f) => fileModel.create({
            name: f.originalname,
            storedName: f.filename,
            mimetype: f.mimetype,
            size: f.size,
            owner: req.user._id,
            folder: folderId
        })));

        res.status(201).json({ files: created });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Upload failed, please try again' });
    }
});

// List contents (folders + files) of a given folder, plus breadcrumb trail
fileRoute.get('/', async (req, res) => {
    try {
        const folderId = req.query.folder && req.query.folder !== 'null' ? req.query.folder : null;

        const [folders, files] = await Promise.all([
            folderModel.find({ owner: req.user._id, parent: folderId, trashed: false }).sort({ name: 1 }),
            fileModel.find({ owner: req.user._id, folder: folderId, trashed: false }).sort({ name: 1 })
        ]);

        let breadcrumb = [];
        if (folderId) {
            let current = await folderModel.findOne({ _id: folderId, owner: req.user._id });
            while (current) {
                breadcrumb.unshift({ _id: current._id, name: current.name });
                if (!current.parent) break;
                current = await folderModel.findOne({ _id: current.parent, owner: req.user._id });
            }
        }

        res.json({ folders, files, breadcrumb });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Could not load files' });
    }
});

// Search across all of the user's files and folders
fileRoute.get('/search', async (req, res) => {
    try {
        const q = (req.query.q || '').trim();
        if (!q) return res.json({ folders: [], files: [] });

        const regex = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');

        const [folders, files] = await Promise.all([
            folderModel.find({ owner: req.user._id, trashed: false, name: regex }),
            fileModel.find({ owner: req.user._id, trashed: false, name: regex })
        ]);

        res.json({ folders, files });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Search failed' });
    }
});

// Starred items
fileRoute.get('/starred', async (req, res) => {
    try {
        const [folders, files] = await Promise.all([
            folderModel.find({ owner: req.user._id, trashed: false, starred: true }).sort({ name: 1 }),
            fileModel.find({ owner: req.user._id, trashed: false, starred: true }).sort({ name: 1 })
        ]);
        res.json({ folders, files });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Could not load starred items' });
    }
});

// Trash listing
fileRoute.get('/trash', async (req, res) => {
    try {
        const [folders, files] = await Promise.all([
            folderModel.find({ owner: req.user._id, trashed: true }).sort({ trashedAt: -1 }),
            fileModel.find({ owner: req.user._id, trashed: true }).sort({ trashedAt: -1 })
        ]);
        res.json({ folders, files });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Could not load trash' });
    }
});

// Storage usage summary
fileRoute.get('/storage', async (req, res) => {
    try {
        const agg = await fileModel.aggregate([
            { $match: { owner: req.user._id, trashed: false } },
            { $group: { _id: null, total: { $sum: '$size' }, count: { $sum: 1 } } }
        ]);
        const used = agg.length ? agg[0].total : 0;
        const count = agg.length ? agg[0].count : 0;
        const quota = 15 * 1024 * 1024 * 1024; // 15 GB, Drive-style display quota
        res.json({ used, count, quota });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Could not load storage info' });
    }
});

// Download a file
fileRoute.get('/download/:id', async (req, res) => {
    try {
        const file = await fileModel.findOne({ _id: req.params.id, owner: req.user._id });
        if (!file) return res.status(404).json({ message: 'File not found' });

        const filePath = path.join(upload.uploadRoot, String(req.user._id), file.storedName);
        if (!fs.existsSync(filePath)) return res.status(404).json({ message: 'File missing on disk' });

        res.download(filePath, file.name);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Download failed' });
    }
});

// Move a file into a different folder (folder: null moves it to root)
fileRoute.patch('/:id/move', async (req, res) => {
    try {
        const folderId = req.body.folder && req.body.folder !== 'null' ? req.body.folder : null;
        const file = await fileModel.findOneAndUpdate(
            { _id: req.params.id, owner: req.user._id },
            { folder: folderId },
            { new: true }
        );
        if (!file) return res.status(404).json({ message: 'File not found' });

        res.json({ file });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Could not move file' });
    }
});

// Rename a file
fileRoute.patch('/:id/rename', async (req, res) => {
    try {
        const { name } = req.body;
        if (!name || !name.trim()) return res.status(400).json({ message: 'Name cannot be empty' });

        const file = await fileModel.findOneAndUpdate(
            { _id: req.params.id, owner: req.user._id },
            { name: name.trim() },
            { new: true }
        );
        if (!file) return res.status(404).json({ message: 'File not found' });

        res.json({ file });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Rename failed' });
    }
});

// Toggle star
fileRoute.patch('/:id/star', async (req, res) => {
    try {
        const file = await fileModel.findOne({ _id: req.params.id, owner: req.user._id });
        if (!file) return res.status(404).json({ message: 'File not found' });

        file.starred = !file.starred;
        await file.save();

        res.json({ file });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Could not update star' });
    }
});

// Move a file to trash
fileRoute.patch('/:id/trash', async (req, res) => {
    try {
        const file = await fileModel.findOneAndUpdate(
            { _id: req.params.id, owner: req.user._id },
            { trashed: true, trashedAt: new Date() },
            { new: true }
        );
        if (!file) return res.status(404).json({ message: 'File not found' });

        res.json({ file });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Could not move file to trash' });
    }
});

// Restore a file from trash
fileRoute.patch('/:id/restore', async (req, res) => {
    try {
        const file = await fileModel.findOneAndUpdate(
            { _id: req.params.id, owner: req.user._id },
            { trashed: false, trashedAt: null },
            { new: true }
        );
        if (!file) return res.status(404).json({ message: 'File not found' });

        res.json({ file });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Could not restore file' });
    }
});

// Permanently delete a file
fileRoute.delete('/:id', async (req, res) => {
    try {
        const file = await fileModel.findOneAndDelete({ _id: req.params.id, owner: req.user._id });
        if (!file) return res.status(404).json({ message: 'File not found' });

        const filePath = path.join(upload.uploadRoot, String(req.user._id), file.storedName);
        if (fs.existsSync(filePath)) fs.unlinkSync(filePath);

        res.json({ message: 'File deleted permanently' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Delete failed' });
    }
});

module.exports = fileRoute;
