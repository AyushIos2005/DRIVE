const express = require('express');
const fs = require('fs');
const path = require('path');

const folderRoute = express.Router();

const authMiddleware = require('../middleware/auth.middleware');
const folderModel = require('../models/folder.model');
const fileModel = require('../models/file.model');
const upload = require('../middleware/upload.middleware');

folderRoute.use(authMiddleware);

// Create a folder
folderRoute.post('/', async (req, res) => {
    try {
        const { name, parent } = req.body;
        if (!name || !name.trim()) return res.status(400).json({ message: 'Folder name cannot be empty' });

        const folder = await folderModel.create({
            name: name.trim(),
            owner: req.user._id,
            parent: parent && parent !== 'null' ? parent : null
        });

        res.status(201).json({ folder });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Could not create folder' });
    }
});

// Move a folder into a different parent folder (parent: null moves it to root)
folderRoute.patch('/:id/move', async (req, res) => {
    try {
        const parentId = req.body.parent && req.body.parent !== 'null' ? req.body.parent : null;

        if (String(parentId) === String(req.params.id)) {
            return res.status(400).json({ message: 'A folder cannot be moved into itself' });
        }

        const folder = await folderModel.findOneAndUpdate(
            { _id: req.params.id, owner: req.user._id },
            { parent: parentId },
            { new: true }
        );
        if (!folder) return res.status(404).json({ message: 'Folder not found' });

        res.json({ folder });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Could not move folder' });
    }
});

// Rename a folder
folderRoute.patch('/:id/rename', async (req, res) => {
    try {
        const { name } = req.body;
        if (!name || !name.trim()) return res.status(400).json({ message: 'Name cannot be empty' });

        const folder = await folderModel.findOneAndUpdate(
            { _id: req.params.id, owner: req.user._id },
            { name: name.trim() },
            { new: true }
        );
        if (!folder) return res.status(404).json({ message: 'Folder not found' });

        res.json({ folder });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Rename failed' });
    }
});

// Toggle star
folderRoute.patch('/:id/star', async (req, res) => {
    try {
        const folder = await folderModel.findOne({ _id: req.params.id, owner: req.user._id });
        if (!folder) return res.status(404).json({ message: 'Folder not found' });

        folder.starred = !folder.starred;
        await folder.save();

        res.json({ folder });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Could not update star' });
    }
});

// Move a folder (and everything inside it) to trash
folderRoute.patch('/:id/trash', async (req, res) => {
    try {
        const folder = await folderModel.findOneAndUpdate(
            { _id: req.params.id, owner: req.user._id },
            { trashed: true, trashedAt: new Date() },
            { new: true }
        );
        if (!folder) return res.status(404).json({ message: 'Folder not found' });

        await folderModel.updateMany({ owner: req.user._id, parent: folder._id }, { trashed: true, trashedAt: new Date() });
        await fileModel.updateMany({ owner: req.user._id, folder: folder._id }, { trashed: true, trashedAt: new Date() });

        res.json({ folder });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Could not move folder to trash' });
    }
});

// Restore a folder from trash
folderRoute.patch('/:id/restore', async (req, res) => {
    try {
        const folder = await folderModel.findOneAndUpdate(
            { _id: req.params.id, owner: req.user._id },
            { trashed: false, trashedAt: null },
            { new: true }
        );
        if (!folder) return res.status(404).json({ message: 'Folder not found' });

        await folderModel.updateMany({ owner: req.user._id, parent: folder._id }, { trashed: false, trashedAt: null });
        await fileModel.updateMany({ owner: req.user._id, folder: folder._id }, { trashed: false, trashedAt: null });

        res.json({ folder });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Could not restore folder' });
    }
});

// Recursively deletes a folder's files (from disk + db) and sub-folders
async function deleteFolderDeep(ownerId, folderId) {
    const filesInside = await fileModel.find({ owner: ownerId, folder: folderId });
    for (const f of filesInside) {
        const filePath = path.join(upload.uploadRoot, String(ownerId), f.storedName);
        if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    }
    await fileModel.deleteMany({ owner: ownerId, folder: folderId });

    const childFolders = await folderModel.find({ owner: ownerId, parent: folderId });
    for (const child of childFolders) {
        await deleteFolderDeep(ownerId, child._id);
    }
    await folderModel.deleteMany({ owner: ownerId, parent: folderId });
}

// Permanently delete a folder and everything inside it
folderRoute.delete('/:id', async (req, res) => {
    try {
        const folder = await folderModel.findOne({ _id: req.params.id, owner: req.user._id });
        if (!folder) return res.status(404).json({ message: 'Folder not found' });

        await deleteFolderDeep(req.user._id, folder._id);
        await folderModel.deleteOne({ _id: folder._id });

        res.json({ message: 'Folder deleted permanently' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Delete failed' });
    }
});

module.exports = folderRoute;
