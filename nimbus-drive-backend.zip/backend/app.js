require("dotenv").config()
const express = require("express");
const path = require("path");
const userRoute = require("./routes/user.route");
const fileRoute = require("./routes/file.route");
const folderRoute = require("./routes/folder.route");
const db = require("./config/db");
const cookieParser = require('cookie-parser')
const authMiddleware = require("./middleware/auth.middleware");

db();
const app = express();

app.set('view engine', 'ejs');
app.use(cookieParser());
app.use(express.json())
app.use(express.urlencoded({ extended: true }))
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
    res.render("index");
})

app.get('/home', authMiddleware, (req, res) => {
    res.render("home", { user: req.user });
})

app.use("/api/user", userRoute);
app.use("/api/files", fileRoute);
app.use("/api/folders", folderRoute);

app.use((req, res) => {
    res.status(404).json({ message: 'Route not found' })
})

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log('Server is running on port ' + PORT);
})
