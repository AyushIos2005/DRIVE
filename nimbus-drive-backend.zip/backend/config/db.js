const mon = require('mongoose')

function db(){
    mon.connect(process.env.MON_URI).then(() => {
         console.log("DB is Connected ")
    }).catch((err) => {
         console.error("DB connection failed:", err.message)
         process.exit(1)
    })
}

module.exports = db;