(function () {
    'use strict';

    // ---------- State ----------
    const state = {
        view: 'drive',        // drive | starred | trash | search
        folderId: null,       // current folder id (drive view only)
        breadcrumb: [],
        folders: [],
        files: [],
        viewMode: localStorage.getItem('nimbus-view-mode') || 'grid',
        searchQuery: ''
    };

    // ---------- Helpers ----------
    async function api(url, opts = {}) {
        const res = await fetch(url, {
            credentials: 'include',
            headers: opts.body && !(opts.body instanceof FormData) ? { 'Content-Type': 'application/json' } : undefined,
            ...opts
        });
        let data = {};
        try { data = await res.json(); } catch (e) { /* no body */ }
        if (!res.ok) throw new Error(data.message || 'Something went wrong');
        return data;
    }

    function formatBytes(bytes) {
        if (!bytes) return '0 B';
        const units = ['B', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(1024));
        return (bytes / Math.pow(1024, i)).toFixed(i === 0 ? 0 : 1) + ' ' + units[i];
    }

    function toast(msg) {
        const wrap = document.getElementById('toast-wrap');
        const el = document.createElement('div');
        el.className = 'toast';
        el.textContent = msg;
        wrap.appendChild(el);
        setTimeout(() => el.remove(), 2600);
    }

    function fileIconSvg(mimetype) {
        if (mimetype && mimetype.startsWith('image/')) {
            return '<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><rect x="3" y="4" width="18" height="16" rx="2" fill="#e0563f"/><circle cx="9" cy="10" r="2" fill="white" opacity=".9"/><path d="m4 18 5-5 4 3 4-4 3 3" stroke="white" stroke-width="1.6" fill="none" opacity=".9"/></svg>';
        }
        if (mimetype && mimetype.includes('pdf')) {
            return '<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M6 2h9l5 5v13a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2Z" fill="#3457d5"/><text x="6" y="17" font-size="6" fill="white" font-family="sans-serif">PDF</text></svg>';
        }
        if (mimetype && (mimetype.includes('zip') || mimetype.includes('compressed'))) {
            return '<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><rect x="4" y="3" width="16" height="18" rx="2" fill="#e8a33d"/><rect x="10.5" y="3" width="3" height="18" fill="#c8862a"/></svg>';
        }
        if (mimetype && (mimetype.startsWith('video/'))) {
            return '<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><rect x="3" y="4" width="18" height="16" rx="2" fill="#2f9e63"/><path d="M10 9.5v5l4.5-2.5Z" fill="white"/></svg>';
        }
        if (mimetype && (mimetype.startsWith('audio/'))) {
            return '<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><rect x="3" y="4" width="18" height="16" rx="2" fill="#8a5ce8"/><path d="M9 15V9l7-1.4V13" stroke="white" stroke-width="1.4" fill="none"/><circle cx="8" cy="15.5" r="1.6" fill="white"/><circle cx="15" cy="13.5" r="1.6" fill="white"/></svg>';
        }
        return '<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M6 2h9l5 5v13a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2Z" fill="#9a978c"/></svg>';
    }

    const folderIconSvg = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M3 6a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6Z" fill="#e8a33d"/></svg>';

    // ---------- Init ----------
    document.addEventListener('DOMContentLoaded', () => {
        const u = window.__CURRENT_USER__ || {};
        const avatar = document.getElementById('user-avatar');
        avatar.textContent = (u.username || '?').slice(0, 1).toUpperCase();
        avatar.title = u.email || '';

        bindGlobalEvents();
        applyViewMode();
        loadStorage();
        loadCurrentView();
    });

    function bindGlobalEvents() {
        // Sidebar nav
        document.querySelectorAll('[data-view]').forEach((btn) => {
            btn.addEventListener('click', () => {
                state.view = btn.dataset.view;
                state.folderId = null;
                document.querySelectorAll('[data-view]').forEach((b) => b.classList.remove('active'));
                btn.classList.add('active');
                document.getElementById('search-input').value = '';
                loadCurrentView();
            });
        });

        // New button + menu
        const newBtn = document.getElementById('new-btn');
        const newMenu = document.getElementById('new-menu');
        newBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            newMenu.classList.toggle('open');
        });
        document.addEventListener('click', () => newMenu.classList.remove('open'));
        newMenu.querySelectorAll('button').forEach((b) => b.addEventListener('click', (e) => {
            e.stopPropagation();
            newMenu.classList.remove('open');
            if (b.dataset.action === 'new-folder') openFolderModal();
            if (b.dataset.action === 'upload-files') document.getElementById('file-input').click();
        }));

        // File input
        document.getElementById('file-input').addEventListener('change', (e) => {
            if (e.target.files.length) uploadFiles(e.target.files);
            e.target.value = '';
        });

        // Search
        let searchTimer;
        document.getElementById('search-input').addEventListener('input', (e) => {
            clearTimeout(searchTimer);
            searchTimer = setTimeout(() => {
                const q = e.target.value.trim();
                state.searchQuery = q;
                if (q) {
                    state.view = 'search';
                } else {
                    state.view = 'drive';
                }
                loadCurrentView();
            }, 300);
        });

        // View mode toggle
        document.getElementById('grid-view-btn').addEventListener('click', () => setViewMode('grid'));
        document.getElementById('list-view-btn').addEventListener('click', () => setViewMode('list'));

        // Logout
        document.getElementById('logout-btn').addEventListener('click', () => {
            window.location.href = '/api/user/logout';
        });

        // Drag & drop upload from OS
        const contentArea = document.getElementById('content-area');
        const overlay = document.getElementById('drop-overlay');
        let dragCounter = 0;

        contentArea.addEventListener('dragenter', (e) => {
            if (!e.dataTransfer.types.includes('Files')) return;
            e.preventDefault();
            dragCounter++;
            if (state.view === 'drive') overlay.classList.add('active');
        });
        contentArea.addEventListener('dragover', (e) => {
            if (!e.dataTransfer.types.includes('Files')) return;
            e.preventDefault();
        });
        contentArea.addEventListener('dragleave', (e) => {
            dragCounter--;
            if (dragCounter <= 0) { overlay.classList.remove('active'); dragCounter = 0; }
        });
        contentArea.addEventListener('drop', (e) => {
            e.preventDefault();
            dragCounter = 0;
            overlay.classList.remove('active');
            if (state.view !== 'drive') return;
            if (e.dataTransfer.files && e.dataTransfer.files.length) uploadFiles(e.dataTransfer.files);
        });

        // Modal close buttons
        document.querySelectorAll('[data-close-modal]').forEach((b) => {
            b.addEventListener('click', () => closeModal(b.dataset.closeModal));
        });

        // Context menu dismiss on outside click
        document.addEventListener('click', () => {
            document.getElementById('item-ctx-menu').classList.remove('open');
        });
    }

    function setViewMode(mode) {
        state.viewMode = mode;
        localStorage.setItem('nimbus-view-mode', mode);
        applyViewMode();
        renderAll();
    }

    function applyViewMode() {
        const gridBtn = document.getElementById('grid-view-btn');
        const listBtn = document.getElementById('list-view-btn');
        [gridBtn, listBtn].forEach((b) => { b.style.background = 'transparent'; b.style.color = 'var(--text-dim)'; });
        const active = state.viewMode === 'grid' ? gridBtn : listBtn;
        active.style.background = 'white';
        active.style.color = 'var(--ink)';
    }

    // ---------- Loading data ----------
    async function loadStorage() {
        try {
            const data = await api('/api/files/storage');
            const pct = Math.min(100, (data.used / data.quota) * 100);
            document.getElementById('storage-bar').style.width = pct + '%';
            document.getElementById('storage-label').textContent =
                formatBytes(data.used) + ' of ' + formatBytes(data.quota) + ' used';
        } catch (e) { /* silent */ }
    }

    async function loadCurrentView() {
        document.getElementById('loading-state').classList.remove('hidden');
        document.getElementById('folders-section').classList.add('hidden');
        document.getElementById('files-section').classList.add('hidden');
        document.getElementById('empty-state').classList.add('hidden');

        try {
            let data;
            if (state.view === 'drive') {
                data = await api('/api/files?folder=' + (state.folderId || 'null'));
                state.breadcrumb = data.breadcrumb || [];
            } else if (state.view === 'starred') {
                data = await api('/api/files/starred');
                state.breadcrumb = [];
            } else if (state.view === 'trash') {
                data = await api('/api/files/trash');
                state.breadcrumb = [];
            } else if (state.view === 'search') {
                data = await api('/api/files/search?q=' + encodeURIComponent(state.searchQuery));
                state.breadcrumb = [];
            }
            state.folders = data.folders || [];
            state.files = data.files || [];
            renderBreadcrumb();
            renderAll();
        } catch (err) {
            toast(err.message);
        } finally {
            document.getElementById('loading-state').classList.add('hidden');
        }
    }

    function renderBreadcrumb() {
        const el = document.getElementById('breadcrumb');
        el.innerHTML = '';

        const rootLabel = { drive: 'My Drive', starred: 'Starred', trash: 'Trash', search: 'Search results' }[state.view];
        const rootBtn = document.createElement('button');
        rootBtn.className = 'font-display font-semibold px-1.5 py-1 rounded hover:bg-black/5';
        rootBtn.textContent = rootLabel;
        rootBtn.style.color = 'var(--ink)';
        if (state.view === 'drive') {
            rootBtn.addEventListener('click', () => { state.folderId = null; loadCurrentView(); });
        }
        el.appendChild(rootBtn);

        state.breadcrumb.forEach((crumb) => {
            const sep = document.createElement('span');
            sep.textContent = '/';
            sep.style.color = 'var(--text-dim)';
            el.appendChild(sep);

            const b = document.createElement('button');
            b.className = 'px-1.5 py-1 rounded hover:bg-black/5';
            b.textContent = crumb.name;
            b.addEventListener('click', () => { state.folderId = crumb._id; loadCurrentView(); });
            el.appendChild(b);
        });
    }

    // ---------- Rendering ----------
    function renderAll() {
        const fSec = document.getElementById('folders-section');
        const flSec = document.getElementById('files-section');
        const empty = document.getElementById('empty-state');
        const foldersGrid = document.getElementById('folders-grid');
        const filesGrid = document.getElementById('files-grid');

        foldersGrid.innerHTML = '';
        filesGrid.innerHTML = '';
        foldersGrid.className = state.viewMode === 'grid'
            ? 'grid gap-3'
            : 'flex flex-col gap-1.5';
        if (state.viewMode === 'grid') foldersGrid.style.gridTemplateColumns = 'repeat(auto-fill, minmax(230px, 1fr))';
        else foldersGrid.style.gridTemplateColumns = '';

        filesGrid.className = state.viewMode === 'grid'
            ? 'grid gap-3'
            : 'flex flex-col gap-1.5';
        if (state.viewMode === 'grid') filesGrid.style.gridTemplateColumns = 'repeat(auto-fill, minmax(190px, 1fr))';
        else filesGrid.style.gridTemplateColumns = '';

        if (state.folders.length === 0 && state.files.length === 0) {
            empty.classList.remove('hidden');
            empty.classList.add('flex');
            const titleEl = document.getElementById('empty-title');
            const subEl = document.getElementById('empty-sub');
            if (state.view === 'trash') { titleEl.textContent = 'Trash is empty'; subEl.textContent = 'Deleted files and folders show up here.'; }
            else if (state.view === 'starred') { titleEl.textContent = 'No starred items'; subEl.textContent = 'Star files or folders to find them quickly here.'; }
            else if (state.view === 'search') { titleEl.textContent = 'No matches'; subEl.textContent = 'Try a different search term.'; }
            else { titleEl.textContent = 'Nothing here yet'; subEl.textContent = 'Drag files in, or use the New button to get started.'; }
            return;
        }
        empty.classList.add('hidden');
        empty.classList.remove('flex');

        if (state.folders.length) {
            fSec.classList.remove('hidden');
            state.folders.forEach((f) => foldersGrid.appendChild(renderFolderCard(f)));
        } else {
            fSec.classList.add('hidden');
        }

        if (state.files.length) {
            flSec.classList.remove('hidden');
            state.files.forEach((f) => filesGrid.appendChild(renderFileCard(f)));
        } else {
            flSec.classList.add('hidden');
        }
    }

    function baseCard(isGrid) {
        const card = document.createElement('div');
        card.className = 'item-card cursor-pointer bg-white rounded-xl select-none';
        card.style.border = '1px solid var(--line)';
        card.style.padding = isGrid ? '14px' : '10px 14px';
        if (!isGrid) { card.style.display = 'flex'; card.style.alignItems = 'center'; card.style.gap = '12px'; }
        return card;
    }

    function renderFolderCard(folder) {
        const isGrid = state.viewMode === 'grid';
        const card = baseCard(isGrid);
        card.draggable = true;
        card.dataset.id = folder._id;
        card.dataset.type = 'folder';

        card.innerHTML = isGrid ? `
            <div class="flex items-start justify-between mb-2.5">
                ${folderIconSvg}
                ${folder.starred ? starDot() : ''}
            </div>
            <p class="text-sm font-medium truncate" style="color:var(--text)" title="${escapeHtml(folder.name)}">${escapeHtml(folder.name)}</p>
        ` : `
            ${folderIconSvg}
            <p class="text-sm font-medium truncate flex-1" style="color:var(--text)">${escapeHtml(folder.name)}</p>
            ${folder.starred ? starDot() : ''}
        `;

        if (state.view !== 'trash') {
            card.addEventListener('click', () => {
                state.view = 'drive';
                state.folderId = folder._id;
                document.querySelectorAll('[data-view]').forEach((b) => b.classList.remove('active'));
                document.querySelector('[data-view="drive"]').classList.add('active');
                loadCurrentView();
            });
        }

        card.addEventListener('contextmenu', (e) => { e.preventDefault(); showItemMenu(e, 'folder', folder); });

        // drag source
        card.addEventListener('dragstart', (e) => {
            card.classList.add('dragging');
            e.dataTransfer.setData('text/plain', JSON.stringify({ type: 'folder', id: folder._id }));
        });
        card.addEventListener('dragend', () => card.classList.remove('dragging'));

        // drag target (drop file/folder onto this folder to move it inside)
        if (state.view === 'drive') {
            card.addEventListener('dragover', (e) => { e.preventDefault(); card.classList.add('drop-target'); });
            card.addEventListener('dragleave', () => card.classList.remove('drop-target'));
            card.addEventListener('drop', async (e) => {
                e.preventDefault();
                card.classList.remove('drop-target');
                const raw = e.dataTransfer.getData('text/plain');
                if (!raw) return;
                try {
                    const payload = JSON.parse(raw);
                    if (payload.id === folder._id) return;
                    await moveItem(payload.type, payload.id, folder._id);
                    toast('Moved into ' + folder.name);
                    loadCurrentView();
                } catch (e2) { /* not our drag data */ }
            });
        }

        return card;
    }

    function renderFileCard(file) {
        const isGrid = state.viewMode === 'grid';
        const card = baseCard(isGrid);
        card.draggable = state.view === 'drive';
        card.dataset.id = file._id;
        card.dataset.type = 'file';

        card.innerHTML = isGrid ? `
            <div class="flex items-start justify-between mb-2.5">
                ${fileIconSvg(file.mimetype)}
                ${file.starred ? starDot() : ''}
            </div>
            <p class="text-sm font-medium truncate" style="color:var(--text)" title="${escapeHtml(file.name)}">${escapeHtml(file.name)}</p>
            <p class="text-xs mt-1" style="color:var(--text-dim)">${formatBytes(file.size)}</p>
        ` : `
            ${fileIconSvg(file.mimetype)}
            <p class="text-sm font-medium truncate flex-1" style="color:var(--text)">${escapeHtml(file.name)}</p>
            <span class="text-xs shrink-0" style="color:var(--text-dim)">${formatBytes(file.size)}</span>
            ${file.starred ? starDot() : ''}
        `;

        card.addEventListener('dblclick', () => {
            if (state.view !== 'trash') window.open('/api/files/download/' + file._id, '_blank');
        });
        card.addEventListener('contextmenu', (e) => { e.preventDefault(); showItemMenu(e, 'file', file); });

        card.addEventListener('dragstart', (e) => {
            card.classList.add('dragging');
            e.dataTransfer.setData('text/plain', JSON.stringify({ type: 'file', id: file._id }));
        });
        card.addEventListener('dragend', () => card.classList.remove('dragging'));

        return card;
    }

    function starDot() {
        return '<svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="m12 3 2.6 5.9 6.4.6-4.8 4.3 1.4 6.3L12 17l-5.6 3.1 1.4-6.3-4.8-4.3 6.4-.6L12 3Z" fill="#e8a33d"/></svg>';
    }

    function escapeHtml(str) {
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    async function moveItem(type, id, folderId) {
        if (type === 'folder') {
            await api('/api/folders/' + id + '/move', { method: 'PATCH', body: JSON.stringify({ parent: folderId }) });
        } else {
            await api('/api/files/' + id + '/move', { method: 'PATCH', body: JSON.stringify({ folder: folderId }) });
        }
    }

    // ---------- Context menu ----------
    let ctxItem = null;
    function showItemMenu(e, type, item) {
        ctxItem = { type, item };
        const menu = document.getElementById('item-ctx-menu');
        const inTrash = state.view === 'trash';

        let html = '';
        if (!inTrash) {
            if (type === 'file') {
                html += `<button data-a="download">${iconSm('download')} Download</button>`;
            }
            html += `<button data-a="rename">${iconSm('rename')} Rename</button>`;
            html += `<button data-a="star">${iconSm('star')} ${item.starred ? 'Remove star' : 'Add star'}</button>`;
            html += `<hr><button data-a="trash" class="danger">${iconSm('trash')} Move to trash</button>`;
        } else {
            html += `<button data-a="restore">${iconSm('restore')} Restore</button>`;
            html += `<hr><button data-a="delete" class="danger">${iconSm('trash')} Delete forever</button>`;
        }
        menu.innerHTML = html;
        menu.style.left = Math.min(e.clientX, window.innerWidth - 210) + 'px';
        menu.style.top = Math.min(e.clientY, window.innerHeight - 200) + 'px';
        menu.classList.add('open');

        menu.querySelectorAll('button').forEach((b) => {
            b.addEventListener('click', (ev) => { ev.stopPropagation(); handleCtxAction(b.dataset.a); menu.classList.remove('open'); });
        });
    }

    function iconSm(name) {
        const icons = {
            download: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M12 3v12m0 0 5-5m-5 5-5-5M4 20h16" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round"/></svg>',
            rename: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M4 20h4l11-11-4-4L4 16v4Z" stroke="currentColor" stroke-width="1.6" fill="none"/></svg>',
            star: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="m12 3 2.6 5.9 6.4.6-4.8 4.3 1.4 6.3L12 17l-5.6 3.1 1.4-6.3-4.8-4.3 6.4-.6L12 3Z" stroke="currentColor" stroke-width="1.6" fill="none"/></svg>',
            trash: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M4 7h16M9 7V4h6v3m-8 0 1 13a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2l1-13" stroke="currentColor" stroke-width="1.6" fill="none" stroke-linecap="round"/></svg>',
            restore: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M4 4v6h6M4.5 15a8 8 0 1 0 2-9L4 10" stroke="currentColor" stroke-width="1.6" fill="none" stroke-linecap="round"/></svg>'
        };
        return icons[name] || '';
    }

    async function handleCtxAction(action) {
        const { type, item } = ctxItem;
        const base = type === 'folder' ? '/api/folders/' : '/api/files/';
        try {
            if (action === 'download') {
                window.open('/api/files/download/' + item._id, '_blank');
            } else if (action === 'rename') {
                openRenameModal(type, item);
            } else if (action === 'star') {
                await api(base + item._id + '/star', { method: 'PATCH' });
                loadCurrentView();
            } else if (action === 'trash') {
                await api(base + item._id + '/trash', { method: 'PATCH' });
                toast((type === 'folder' ? 'Folder' : 'File') + ' moved to trash');
                loadCurrentView();
                loadStorage();
            } else if (action === 'restore') {
                await api(base + item._id + '/restore', { method: 'PATCH' });
                toast('Restored');
                loadCurrentView();
                loadStorage();
            } else if (action === 'delete') {
                openDeleteModal(type, item);
            }
        } catch (err) {
            toast(err.message);
        }
    }

    // ---------- Modals ----------
    function openModal(id) { document.getElementById(id).classList.add('open'); }
    function closeModal(id) { document.getElementById(id).classList.remove('open'); }

    function openFolderModal() {
        const input = document.getElementById('folder-input');
        input.value = '';
        openModal('folder-modal');
        setTimeout(() => input.focus(), 50);
    }
    document.addEventListener('DOMContentLoaded', () => {
        document.getElementById('folder-confirm-btn').addEventListener('click', createFolder);
        document.getElementById('folder-input').addEventListener('keydown', (e) => { if (e.key === 'Enter') createFolder(); });
        document.getElementById('rename-confirm-btn').addEventListener('click', confirmRename);
        document.getElementById('rename-input').addEventListener('keydown', (e) => { if (e.key === 'Enter') confirmRename(); });
        document.getElementById('delete-confirm-btn').addEventListener('click', confirmDelete);
    });

    async function createFolder() {
        const name = document.getElementById('folder-input').value.trim();
        if (!name) return;
        try {
            await api('/api/folders', { method: 'POST', body: JSON.stringify({ name, parent: state.folderId }) });
            closeModal('folder-modal');
            toast('Folder created');
            loadCurrentView();
        } catch (err) { toast(err.message); }
    }

    let renameTarget = null;
    function openRenameModal(type, item) {
        renameTarget = { type, item };
        const input = document.getElementById('rename-input');
        input.value = item.name;
        openModal('rename-modal');
        setTimeout(() => { input.focus(); input.select(); }, 50);
    }
    async function confirmRename() {
        if (!renameTarget) return;
        const name = document.getElementById('rename-input').value.trim();
        if (!name) return;
        const base = renameTarget.type === 'folder' ? '/api/folders/' : '/api/files/';
        try {
            await api(base + renameTarget.item._id + '/rename', { method: 'PATCH', body: JSON.stringify({ name }) });
            closeModal('rename-modal');
            loadCurrentView();
        } catch (err) { toast(err.message); }
    }

    let deleteTarget = null;
    function openDeleteModal(type, item) {
        deleteTarget = { type, item };
        openModal('delete-modal');
    }
    async function confirmDelete() {
        if (!deleteTarget) return;
        const base = deleteTarget.type === 'folder' ? '/api/folders/' : '/api/files/';
        try {
            await api(base + deleteTarget.item._id, { method: 'DELETE' });
            closeModal('delete-modal');
            toast('Deleted permanently');
            loadCurrentView();
            loadStorage();
        } catch (err) { toast(err.message); }
    }

    // ---------- Upload ----------
    async function uploadFiles(fileList) {
        const formData = new FormData();
        Array.from(fileList).forEach((f) => formData.append('files', f));
        formData.append('folder', state.folderId || 'null');

        toast('Uploading ' + fileList.length + (fileList.length > 1 ? ' files…' : ' file…'));
        try {
            const res = await fetch('/api/files/upload', { method: 'POST', body: formData, credentials: 'include' });
            const data = await res.json();
            if (!res.ok) throw new Error(data.message || 'Upload failed');
            toast('Upload complete');
            if (state.view === 'drive') loadCurrentView();
            loadStorage();
        } catch (err) {
            toast(err.message);
        }
    }
})();
