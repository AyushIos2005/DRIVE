const mongoose = require('mongoose');

const fileSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        trim: true
    },
    storedName: {
        type: String,
        required: true
    },
    mimetype: {
        type: String,
        default: 'application/octet-stream'
    },
    size: {
        type: Number,
        default: 0
    },
    owner: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'user',
        required: true
    },
    folder: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'folder',
        default: null
    },
    starred: {
        type: Boolean,
        default: false
    },
    trashed: {
        type: Boolean,
        default: false
    },
    trashedAt: {
        type: Date,
        default: null
    }
}, { timestamps: true });

fileSchema.index({ owner: 1, folder: 1 });
fileSchema.index({ owner: 1, name: 'text' });

const fileModel = mongoose.model('file', fileSchema);

module.exports = fileModel;
