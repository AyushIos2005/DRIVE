const mon = require('mongoose');

const userSchema = new mon.Schema({
    username : {
        type : String,
        required : true,
        trim : true,
        lowercase : true,
        unique : true,
        minLength : [3,'Username must be at least 3 character long']
    },
    email : {
        type : String,
        required : true,
        trim :true,
        lowercase : true,
        unique : true,
        minLength : [13,'Email must be atleast 13 character long']
    },
    password : {
        type : String,
        required: true,
        trim : true,
        minLength : [5,'Password must be atleast 5 character long']
    }
})

const userModel = mon.model('user',userSchema);

module.exports = userModel;