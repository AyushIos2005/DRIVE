const mongoose = require('mongoose');

const folderSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        trim: true
    },
    owner: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'user',
        required: true
    },
    parent: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'folder',
        default: null
    },
    starred: {
        type: Boolean,
        default: false
    },
    trashed: {
        type: Boolean,
        default: false
    },
    trashedAt: {
        type: Date,
        default: null
    }
}, { timestamps: true });

folderSchema.index({ owner: 1, parent: 1 });

const folderModel = mongoose.model('folder', folderSchema);

module.exports = folderModel;
